//
//  ViewController.swift
//  BillCalculator
//
//  Created by Gurinder Singh on 2020-07-14.
//  Copyright © 2020 Gurinder Singh. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtBillAmount: UITextField!
    
    
    @IBOutlet weak var txtdefaultpercent: UITextField!
 
    
    @IBOutlet weak var txtTotaldefaultAmount: UITextField!
    
    
    @IBOutlet weak var txtNewPercent: UITextField!
    
    
    @IBOutlet weak var txtTotalNEw: UITextField!
    
    
    @IBOutlet weak var labelPercent: UILabel!
    
    
    @IBOutlet weak var Slider: UISlider!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnNumeric(_ sender: UIButton) {
        
    }

    @IBAction func btnOne(_ sender: UIButton) {
        txtBillAmount.text! += "1" ;
    }
    
    @IBAction func btnTeo(_ sender: UIButton) {
        txtBillAmount.text! += "2" ;
    }
    
    @IBAction func btnthree(_ sender: UIButton) {
        txtBillAmount.text! += "3" ;
        
    }
    
    @IBAction func btnfour(_ sender: UIButton) {
        txtBillAmount.text! += "4" ;
    }
    
    @IBAction func btnFive(_ sender: UIButton) {
        txtBillAmount.text! += "5" ;
    }
    
    @IBAction func btnSix(_ sender: UIButton) {
        txtBillAmount.text! += "6" ;
    }
    
    @IBAction func btnSeven(_ sender: UIButton) {
        txtBillAmount.text! += "7" ;
    }
    
    @IBAction func btnEight(_ sender: UIButton) {
        txtBillAmount.text! += "8" ;
    }
    
    @IBAction func btnNine(_ sender: UIButton) {
        txtBillAmount.text! += "9" ;
    }
    
    
    @IBAction func btnDot(_ sender: UIButton) {
        txtBillAmount.text! += "." ;
    }
    
    
    @IBAction func btnZero(_ sender: UIButton) {
        txtBillAmount.text! += "0" ;
    }
    
    
    @IBAction func btnClear(_ sender: UIButton) {
        txtBillAmount.text! = "" ;
    }
    
    @IBAction func txtdefaultAmount(_ sender: UITextField) {
    }
    
    
    @IBAction func SlidderPercent(_ sender: UISlider) {
    
    }
    
    
    
    
    
    
}

