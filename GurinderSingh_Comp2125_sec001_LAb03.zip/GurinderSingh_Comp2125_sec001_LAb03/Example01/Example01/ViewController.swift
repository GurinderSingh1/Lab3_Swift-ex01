//
//  ViewController.swift
//  Example01
//
//  Created by Gurinder Singh on 2020-07-14.
//  Copyright © 2020 Gurinder Singh. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
// outlets
    
    @IBOutlet weak var txtUsername: UITextField!
    
    @IBOutlet weak var txtPassword: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func btnLogin(_ sender: Any) {
    }
    
}

